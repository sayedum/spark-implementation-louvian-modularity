import community
import networkx as nx
#from IPython.display import display
import matplotlib.pyplot as plt
#%matplotlib inline
# Replace this with your networkx graph loading depending on your format !
#G = nx.erdos_renyi_graph(30, 0.05)
#pos = nx.spring_layout(G)
#count = 0
#nx.draw_networkx_edges(G, pos, alpha=0.5)
#plt.show()


graph = nx.Graph()
#graph = nx.read_edgelist("D:\MSc Data Science and Analytics\des algorithms\project\my-implementations\edgelist.classnote.weight.str")
graph = nx.read_edgelist("D:\MSc Data Science and Analytics\des algorithms\project\my-implementations\datasets/email-Eu-core.txt")

#print(list(graph))
G = graph
nx.draw(G)
plt.show()

#first compute the best partition
partition = community.best_partition(G)

#drawing
size = float(len(set(partition.values())))
pos = nx.spring_layout(G)
count = 0.
for com in set(partition.values()) :
    count = count + 1.
    list_nodes = [nodes for nodes in partition.keys()
                                if partition[nodes] == com]
    nx.draw_networkx_nodes(G, pos, list_nodes, node_size = 20,
                                node_color = str(count / size))


nx.draw_networkx_edges(G, pos, alpha=0.5)
plt.show()