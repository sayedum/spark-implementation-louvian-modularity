#!/usr/bin/python3.6
import numpy as np
import community
import networkx as nx
print('hello world')

#G = nx.DiGraph()
G = nx.Graph()
G = nx.read_edgelist('edgelist.classnote.weight.str')
print(list(G.edges(data=True)))

part = nx.best_partition(G)
