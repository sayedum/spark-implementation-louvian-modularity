import numpy
import networkx
print('hello world')
