#!/bin/bash

for totalFileCount in $(hadoop fs -ls /user/root/final-exam/testbbcsport/cricket | wc -l)
#for totalFileCount in $(hadoop fs -ls /user/root/final-exam/simple-files | wc -l)
do
        break
done

for aFile in $(hadoop fs -ls /user/root/final-exam/testbbcsport/cricket/*.txt | awk '{print $8}')
#for aFile in $(hadoop fs -ls /user/root/final-exam/simple-files/*.txt | awk '{print $8}')
do
    echo "Processing the file: $aFile "
    #eval "hadoop fs -rm -r $afile-out"
    #echo "$aFile-out"
    #continue
    fileWithCount="$aFile~$totalFileCount"
    #echo $fileWithCount
   
    spark-submit --master yarn-client --executor-memory 1g --num-executors 3 --executor-cores 2 --driver-memory 1g clean-final-tf-idf-calculation-spark.py --ngrams $fileWithCount
    
done
