#!/bin/bash

   
spark-submit --master yarn-client --executor-memory 1g --num-executors 3 --executor-cores 2 --driver-memory 1g implement-louvain-modularity.py  --ngrams $fileWithCount
