import networkx as nx
from pyspark import SparkConf, SparkContext
from pyspark.sql import SQLContext
#from graphframes.examples import * 
from graphframes import *


def makeTuple(line):
    words = line.split()
    return (words[0].strip(), words[1].strip())
	

def makeSeparate(line):
    words = line#.split()
    l = []
    l.append(words[0])
    l.append(words[1])
    return l


def main(sc):
    sqlContext = SQLContext(sc)
    #non-spark reading of graph from file
    graph = nx.Graph()
    graph = nx.read_edgelist('edgelist.classnote.weight.str', nodetype=str)
    print(list(graph.nodes))


	# convert graph data to GraphFrame
	# Vertex DataFrame
	v = sqlContext.createDataFrame(list(graph.nodes), ["id"])
	# Edge DataFrame
	e = sqlContext.createDataFrame(list(graph.edges), ["src", "dst"])
	# Create a GraphFrame
	g = GraphFrame(v, e)



	#G = nx.DiGraph()
	#G = nx.Graph()
	#G = nx.read_edgelist('polblogs.edgelist.simple_format', nodetype=str, create_using=nx.DiGraph())
	#G=G.to_directed()


	input_file = sc.textFile('/user/root/louvain/edgelist.classnote.weight.str')
	edges = input_file.map(lambda x: makeTuple(x))


	e = sqlContext.createDataFrame(edges, ["src", "dst"])
	e.show()

	v = edges.map(lambda line: makeSeparate(line))


	#for x in edges:
	#  print(x)


	vertices = []
	for x in edges.collect():
      		vertices.append(x[0])
      		vertices.append(x[1])

	vertice_set = set (vertices)
	vertices = []

	for aNode in vertice_set:
		vertices.append( (aNode, "" ) )

	# convert graph data to GraphFrame
	# Vertex DataFrame
	v = sqlContext.createDataFrame(vertices, ["id", ''])
	# Edge DataFrame
	e = sqlContext.createDataFrame(edges, ["src", "dst"])
	# Create a GraphFrame
	g = GraphFrame(v, e)


if __name__  == "__main__":
	conf = SparkConf().setAppName("MyApp")
	sc = SparkContext(conf = conf)
	main(sc)
	sc.stop()



# References:

# read graph file using spark: https://stackoverflow.com/questions/41144218/pyspark-creating-a-data-frame-from-text-file
# https://networkx.github.io/documentation/stable/reference/readwrite/generated/networkx.readwrite.edgelist.read_edgelist.html
# read_edgelist(path, comments='#', delimiter=None, create_using=None, nodetype=None, data=True, edgetype=None, encoding='utf-8')
