# vertex DataFrame

v = sqlContext.createDataFrame(

[
  ("a", "Alice", 34),
  ("b", "bob", 36),
  ("c", "charlie", 30),
  ("d", "David", 29),
  ("e", "Esther", 32),
  ("f", "Fanny", 36),
],

[ "id", "name", "age" ]

)

# edge dataframe
e = sqlContext.createDataFrame(
[
    ("a", "b", "friend"),
    ("b", "c", "follow"),
    ("c", "b", "follow"),
    ("f", "c", "follow"),
    ("e", "f", "follow"),
    ("e", "d", "friend"),
    ("d", "a", "friend"),
],

["src", "dst", "relationship"]

)

g =  GraphFrame(v, e)
from graphframes.examples import Graphs
g = Graphs(sqlContext).friends()

g.vertices.show()
