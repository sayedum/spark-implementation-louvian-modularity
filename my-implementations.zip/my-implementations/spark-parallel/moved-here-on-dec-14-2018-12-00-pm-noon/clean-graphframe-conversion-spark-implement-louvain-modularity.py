from pyspark import SparkConf, SparkContext
from pyspark.sql import SQLContext
from graphframes import *

#make tuples from line
def makeTuple(line):
	words = line.split()
	return words[0].strip(), words[1].strip()

def makeReverseTuple(line):
        words = line.split()
        return words[1].strip(), words[0].strip()

	
# start of the program
inputFilePath = '/user/root/louvain/dataset/quora.txt'
def main(sc):
	#spark reading of graph from file
	input_file = sc.textFile(inputFilePath)

        #EDGES
	edges = input_file.map(lambda x: makeTuple(x))
        edges_df = edges.toDF()

        reverse_edges = input_file.map(lambda x: makeTuple(x))
	reverse_edges_df = reverse_edges.toDF()

        all_edges_combined = edges.union(reverse_edges)
	#all_edges.sortByKey() #sort probably will not help
	all_edges_df_combined = edges_df.union(reverse_edges_df) 
        
 	#from pyspark.sql.types import SparkSession
	###from pyspark.sql.types import StructType, StructField, StructField, StringType
	from pyspark.sql import SparkSession
	spark = SparkSession \
        	.builder \
        	.appName("louvain modularity spark graphframe") \
        	.getOrCreate()

        # convert edges to dataframe
	all_edges_df_table = all_edges_df_combined.createOrReplaceTempView("all_edges_df_table")
	all_edges_df_table_data = spark.sql("select * from all_edges_df_table ")
	
	edge_count_src = spark.sql("select max(src) as s_node, count(*)/2 as src_outgoing_edge_count from  all_edges_df_table  group by src order by int(s_node)")
	edge_count_dst = spark.sql("select max(dst) as d_node, count(*)/2 as dst_outgoing_edge_count from  all_edges_df_table  group by dst order by int(d_node)")


	combined_outgoing_edge_count = all_edges_df_table_data.join(edge_count_src, all_edges_df_table_data.src==edge_count_src.s_node).join(edge_count_dst, all_edges_df_table_data.dst == edge_count_dst.d_node)


	node_edge_list_source = spark.sql("select src as n_src , concat_ws(',', collect_list(dst)) as edges_from_source from  all_edges_df_table group by src")


	all_edges_df_table_with_edges = combined_outgoing_edge_count.join(node_edge_list_source, combined_outgoing_edge_count.src==node_edge_list_source.n_src)


	#node_edge_list_1 = spark.sql("select src, concat_ws(',', collect_list(dst)) as edges from  ll_edges_df_table group by src")
	#node_edge_list_2 = spark.sql("select dst, concat_ws(',', collect_list(src)) as edges from  all_edges_df_table   group by dst")
        
	#node_edge_list = node_edge_list_1.union(node_edge_list_2)
	#node_edge_list.show()

	
	communities = all_edges_df_table_with_edges
	communities.show()


	# count total number of edges
	communities.createOrReplaceTempView("communities_table")
	#use of variables
	total_edge_count = spark.sql('select sum(src_outgoing_edge_count) total_edge_count from communities_table')
	total_edge_count = total_edge_count.take(1)
	two_m = total_edge_count[0].__getitem__("total_edge_count")

	# calculate initial Q values for all nodes
	initial_and_merged_q_values =  spark.sql("SELECT src, dst, src_outgoing_edge_count, dst_outgoing_edge_count, edges_from_source, src_outgoing_edge_count * src_outgoing_edge_count/{} as initial_q_val,   src_outgoing_edge_count * dst_outgoing_edge_count/{} as q_value_if_merged,        communities_table.*  from communities_table".format(two_m, two_m))
	initial_and_merged_q_values.show()


	# I could create a table from previous data frame that could make the sql look pretty
        # also the diff could be calculated in the prev sql as well
	q_value_gain_if_merged = spark.sql("SELECT src as q_diff_src, src_outgoing_edge_count * src_outgoing_edge_count/{} - src_outgoing_edge_count * dst_outgoing_edge_count/{} as q_val_diff_if_merged  from communities_table".format(two_m, two_m))
	q_value_gain_if_merged.show()	

       combine_diff_q_values = initial_and_merged_q_values.join(q_value_gain_if_merged, q_value_gain_if_merged.q_diff_src==initial_and_merged_q_values.src)
	combine_diff_q_values.show()
	


	#get q values and differences at the same time
	#merge_q_values =  spark.sql("SELECT ee.src, ee.dst,ee.src_outgoing_count * ee.src_outgoing_count/{} as previous_q, ee.src_outgoing_count*ee.dst_outgoing_count/{} as merge_q_val,  ee.src_outgoing_count * ee.src_outgoing_count/{}  -  ee.src_outgoing_count*ee.dst_outgoing_count/{} from edges_table ee ".format(two_m, two_m, two_m, two_m))


	# now we are at a stage to combine nodes for communities
	# at each stage/iteration, check the q_val increase by source, and take the maximum merged among +ves and combine


	# count total number of edges
        combine_diff_q_values.createOrReplaceTempView("table_for_community_detection")

	grouped_for_max_change = spark.sql("select first(src), first(dst), max(q_val_diff_if_merged) from table_for_community_detection group by src order by q_val_diff_if_merged desc")



if __name__  == "__main__":
	conf = SparkConf().setAppName("Spark Louvain Modularity")
	sc = SparkContext(conf = conf)
	main(sc)
	sc.stop()



# References:
# read graph file using spark: https://stackoverflow.com/questions/41144218/pyspark-creating-a-data-frame-from-text-file
# https://networkx.github.io/documentation/stable/reference/readwrite/generated/networkx.readwrite.edgelist.read_edgelist.html
# read_edgelist(path, comments='#', delimiter=None, create_using=None, nodetype=None, data=True, edgetype=None, encoding='utf-8')
