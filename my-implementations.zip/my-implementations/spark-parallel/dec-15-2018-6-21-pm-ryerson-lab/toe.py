#spark reading of graph from file
input_file = sc.textFile(inputFilePath)
#EDGES
edges = input_file.map(lambda x: makeTuple(x))
edges_df = edges.toDF(["src", "dst"])
reverse_edges = input_file.map(lambda x: makeReverseTuple(x))
reverse_edges_df = reverse_edges.toDF(["src", "dst"])
all_edges_combined = edges.union(reverse_edges)
#all_edges.sortByKey() #sort probably will not help
all_edges_df_combined = edges_df.union(reverse_edges_df)
# convert edges to dataframe
all_edges_df_table = all_edges_df_combined.createOrReplaceTempView("all_edges_df_table")
all_edges_df_table_data = spark.sql("select * from all_edges_df_table ")
edges_df.registerTempTable('edges_df')
edge_count_src = spark.sql("select max(src) as s_node, count(*) as src_outgoing_edge_count from  edges_df  group by src") # order by int(s_node)")
# as this is reverse edges hence src column is the destination node in the input file
reverse_edges_df.registerTempTable('reverse_edges_df')
edge_count_dst = spark.sql("select max(src) as d_node, count(*) as dst_outgoing_edge_count from  reverse_edges_df  group by src") # order by int(d_node)")
combined_outgoing_edge_count_src = edges_df.join(edge_count_src, edges_df.src==edge_count_src.s_node)
combined_outgoing_edge_count_dst = reverse_edges_df.join(edge_count_dst, reverse_edges_df.src==edge_count_dst.d_node)
# works though need cleaning
#df_data_for_modularity_src =combined_outgoing_edge_count_src.join(combined_outgoing_edge_count_dst,  (   (combined_outgoing_edge_count_src.src==combined_outgoing_edge_count_dst.dst)   &     (combined_outgoing_edge_count_src.dst==combined_outgoing_edge_count_dst.src) ) )
df_data_for_modularity_src =combined_outgoing_edge_count_src.join(combined_outgoing_edge_count_dst,  (   (combined_outgoing_edge_count_src.src==combined_outgoing_edge_count_dst.dst)   &     (combined_outgoing_edge_count_src.dst==combined_outgoing_edge_count_dst.src) ) ).select(combined_outgoing_edge_count_src.src, combined_outgoing_edge_count_src.dst,  combined_outgoing_edge_count_src.src_outgoing_edge_count,  combined_outgoing_edge_count_dst.dst_outgoing_edge_count )
df_data_for_modularity_src.registerTempTable("df_data_for_modularity_src_table")
modularity_table_reverse_edges=spark.sql("select dst as src, src as dst, dst_outgoing_edge_count as src_outgoing_edge_count, src_outgoing_edge_count as dst_outgoing_edge_count from df_data_for_moduly_src_table  ")
