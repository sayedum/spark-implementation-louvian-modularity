
from pyspark.sql.functions import udf

@udf("integer")



combined_outgoing_edge_count = edges_df.join(edge_count_src, edges_df.src==edge_count_src.s_node)

combined_outgoing_edge_count_d = reverse_edges_df.join(edge_count_dst, reverse_edges_df.src==edge_count_dst.d_node)

#x probably wrong

 x=combined_outgoing_edge_count.join(combined_outgoing_edge_count_d,  (combined_outgoing_edge_count.src==combined_outgoing_edge_count_d.dst) and (combined_outgoing_edge_count.dst==combined_outgoing_edge_count_d.src)   )

x=combined_outgoing_edge_count.union(combined_outgoing_edge_count_d)

 xx=combined_outgoing_edge_count.join(combined_outgoing_edge_count_d,  (   (combined_outgoing_edge_count.src==combined_outgoing_edge_count_d.dst)   &     (combined_outgoing_edge_count.dst==combined_outgoing_edge_count_d.src) ) )
