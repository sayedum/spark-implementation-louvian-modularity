from pyspark import SparkConf, SparkContext
from pyspark.sql import SQLContext
#from graphframes.examples import * 
from graphframes import *

#make tuples from line
def makeTuple(line):
	words = line.split()
	return words[0].strip(), words[1].strip()

        #return 	( words[0].strip(), words[1].strip()), ( words[1].strip(), words[0].strip())	
	#return (words[0].strip(), words[1].strip(), "1", "1", "1", "1", "1", "1", "1", "1")



def makeReverseTuple(line):
        words = line.split()
        return words[1].strip(), words[0].strip()

	
# find all tokens
def makeSeparate(line):
	words = line#.split()
	l = []
	l.append(words[0])
	l.append(words[1])
	return l

def calculate_initial_parameter_values(sc, g, v, e):
	print('hello')

# start of the program
inputFilePath = '/user/root/louvain/dataset/quora.txt'
def main(sc):
	#sqlContext = SQLContext(sc)
	#spark reading of graph from file
	input_file = sc.textFile(inputFilePath)

        #EDGES
	edges = input_file.map(lambda x: makeTuple(x))
        edges_df = edges.toDF()

        reverse_edges = input_file.map(lambda x: makeTuple(x))
	reverse_edges_df = reverse_edges.toDF()

        all_edges_combined = edges.union(reverse_edges)
	#all_edges.sortByKey() #sort probably will not help
	all_edges_df_combined = edges_df.union(reverse_edges_df) 
        

"""
	e = sqlContext.createDataFrame(edges, ["src", "dst", "src-outgoing-count", "dst-outgoing-count", "total-count-src-dst", "initial Q", "src-dst-q-change", "best-q-change", "best-dst-node", 'edge-destinations' ])
	e.show()

        # VERTICES
	v = edges.map(lambda line: makeSeparate(line))
	vertices = []
	for x in edges.collect():
      	    vertices.append(x[0])
      	    vertices.append(x[1])
	vertice_set = set (vertices)
	vertices = []
	for aNode in vertice_set:
	    vertices.append( (aNode, "" ) )
	# convert graph data to GraphFrame
	# Vertex DataFrame
	v = sqlContext.createDataFrame(vertices, ["id", ''])
	# Edge DataFrame
	e = sqlContext.createDataFrame(edges, ["src", "dst"])
	# Create a GraphFrame
	g = GraphFrame(v, e)
	g.vertices.show()

"""
 	#from pyspark.sql.types import SparkSession
	###from pyspark.sql.types import StructType, StructField, StructField, StringType
	from pyspark.sql import SparkSession
	spark = SparkSession \
        	.builder \
        	.appName("louvain modularity spark graphframe") \
        	.getOrCreate()

        # convert edges to dataframe
	###ee = sqlContext.createDataFrame(edges)
	#convert dataframe to tables
	###ee.createOrReplaceTempView("edges_table")
	all_edges_df_table = all_edges_df_combined.createOrReplaceTempView("all_edges_df_table")
        
	###all_from_edges = spark.sql("select * from edges_table")
	###all_from_edges.show()


	"""
        ###
	# create schema based tables for edge
	from pyspark.sql.types import StructType, StructField, StructField, StringType
	#edgesSchema = StructType([StructField("src", StringType(), True), StructField("dst", StringType(), True)])
	edgesSchema = StructType([StructField("src", StringType(), True)
		, StructField("dst", StringType(), True)
		, StructField("src_outgoing_count", StringType(), True)
		, StructField("dst_outgoing_count", StringType(), True)
		, StructField("total_outgoing", StringType(), True)
		, StructField("initial_q", StringType(), True)
		, StructField("src_dst_q_change", StringType(), True)
		, StructField("best_q_val", StringType(), True)
		, StructField("best_dst_node", StringType(), True)
		, StructField("edge_destinations", StringType(), True)
		])
	ee = sqlContext.createDataFrame(edges, edgesSchema)


	#convert dataframe to tables
	ee.createOrReplaceTempView("edges_table")

	all_from_edges = spark.sql("select * from edges_table order by src, dst")
	all_from_edges.show()

	"""

	graph=all_from_edges
	graph.show()

	
	node_list_1 = spark.sql("select max(src) as node, count(*) as outgoing_edge_count from edges_table group by src order by int(node)")
	node_list_1.show()

	node_list_2 = spark.sql("select max(dst) as node, count(*) as outgoing_edge_count from edges_table group by dst order by int(node)")
	node_list_2.show()


	node_list=node_list_1.union(node_list_2)
	node_list.show()

	node_edge_list_1 = spark.sql("select src, concat_ws(',', collect_list(dst)) as edges from edges_table group by src")
	node_edge_list_2 = spark.sql("select dst, concat_ws(',', collect_list(src)) as edges from edges_table group by dst")
        
	node_edge_list = node_edge_list_1.union(node_edge_list_2)
	node_edge_list.show()

	
	communities = node_list
	communities.show()


	# count total number of edges
	communities.createOrReplaceTempView("communities_table")
	total_edge_count = spark.sql('select sum(outgoing_edge_count) total_edge_count from communities_table')
	total_edge_count.show()


	two_m = two_m[0].__getitem__("two_m")
	two_m = two_m[0].asDict()["two_m"]


	#use of variables
	total_edge_count = spark.sql('select sum(outgoing_edge_count) total_edge_count from communities_table')
	total_edge_count = total_edge_count.take(1)
	two_m=total_edge_count[0].__getitem__("total_edge_count")

	Q1 = spark.sql("SELECT src from edges_table where dst>5 limit {}".format(two_m))
	Q1.show()

	# calculate initial Q values for all nodes
	#initial_q_values = spark.sql(" SELECT outgoing_edge_count * outgoing_edge_count/{} from communities_table".format(two_m))
	#initial_q_values =  spark.sql("SELECT node, outgoing_edge_count, outgoing_edge_count * outgoing_edge_count/{} from communities_table".format(two_m))
	initial_q_values =  spark.sql("SELECT node, outgoing_edge_count, outgoing_edge_count * outgoing_edge_count/{} as initial_q_val from communities_table".format(two_m))
	initial_q_values.show()

	ee_initial_q_values =  spark.sql("SELECT ee.src, ee.dst, ee.src_outgoing_count * ee.src_outgoing_count/{} as initial_q_val from edges_table ee".format(two_m))


 	merge_q_values =  spark.sql("SELECT ee.src, ee.dst, ee.src_outgoing_count * ee.dst_outgoing_count/{} as merge_q_val from edges_table ee".format(two_m))



	matcheddocumentsandwords = initial_q_values.join(merge_q_values, merge_q_values.src==initial_q_values.node)


	#get q values and differences at the same time
	merge_q_values =  spark.sql("SELECT ee.src, ee.dst,ee.src_outgoing_count * ee.src_outgoing_count/{} as previous_q, ee.src_outgoing_count*ee.dst_outgoing_count/{} as merge_q_val,  ee.src_outgoing_count * ee.src_outgoing_count/{}  -  ee.src_outgoing_count*ee.dst_outgoing_count/{} from edges_table ee ".format(two_m, two_m, two_m, two_m))



if __name__  == "__main__":
	conf = SparkConf().setAppName("Spark Louvain Modularity")
	sc = SparkContext(conf = conf)
	main(sc)
	sc.stop()



# References:
# read graph file using spark: https://stackoverflow.com/questions/41144218/pyspark-creating-a-data-frame-from-text-file
# https://networkx.github.io/documentation/stable/reference/readwrite/generated/networkx.readwrite.edgelist.read_edgelist.html
# read_edgelist(path, comments='#', delimiter=None, create_using=None, nodetype=None, data=True, edgetype=None, encoding='utf-8')
