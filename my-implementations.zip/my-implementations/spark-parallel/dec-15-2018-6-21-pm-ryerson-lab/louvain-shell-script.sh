#!/bin/bash

   
spark-submit --packages graphframes:graphframes:0.6.0-spark2.3-s_2.11   --master yarn-client --executor-memory 1g --num-executors 3 --executor-cores 2 --driver-memory 1g loop-clean-graphframe-conversion-spark-implement-louvain-modularity.py 
