from pyspark import SparkConf, SparkContext
from pyspark.sql import SQLContext
from graphframes import *
#from pyspark.sql.types import SparkSession
###from pyspark.sql.types import StructType, StructField, StructField, StringType
from pyspark.sql import SparkSession


#make tuples from line
def makeTuple(line):
	words = line.split()
	return words[0].strip(), words[1].strip()

#make reverse tuples - for reverse edges
def makeReverseTuple(line):
        words = line.split()
        return words[1].strip(), words[0].strip()

global_node_just_merged = []
def merge_nodes(line):
	src = int(line['src'])
	dst = int(line['dst'])
	if (src in global_node_just_merged ) or (dst in global_node_just_merged):
		return ""
	if src < dst:
		merged_node = str(src) + '~' + str(dst)
	else:
		merged_node = str(dst) + '~' + str(src)
	edges_from_source = line['edges_from_source']
	edges_from_source_split = line['edges_from_source'].split(',')
	if (str(dst) in edges_from_source_split):
		edges_from_source_split.remove(str(dst))
	if (str(dst) in global_node_just_merged):
                edges_from_source_split.remove(str(dst))
	src_outgoing_edge_count = int(line['src_outgoing_edge_count']) + int(line['dst_outgoing_edge_count']) - 2
	initial_q_val = line['q_value_if_merged']
	q_value_if_merged = 0
	q_val_diff_if_merged = 0
	lines_to_return = []
	for item in edges_from_source_split:
		t = (merged_node, item, src_outgoing_edge_count, src_outgoing_edge_count, ','.join(edges_from_source_split), initial_q_val, q_value_if_merged, q_val_diff_if_merged)
		lines_to_return.append(t)
	global_node_just_merged.append(src)
	global_node_just_merged.append(dst)
	return lines_to_return

#global_node_just_merged = []	
#pp=t1.rdd.map(lambda x: merge_nodes(x, global_node_just_merged))

# start of the program
inputFilePath = '/user/root/louvain/dataset/quora.txt'
def main(sc):

	#first create some essential objects/variables
        #without SQLContext  rdd.toDF() does not work
	sqlContext = SQLContext(sc)
	spark = SparkSession \
                .builder \
                .appName("louvain modularity spark graphframe") \
                .getOrCreate()


	#spark reading of graph from file
	input_file = sc.textFile(inputFilePath)

        #EDGES
	edges = input_file.map(lambda x: makeTuple(x))
	edges_df = edges.toDF(["src", "dst"])

	reverse_edges = input_file.map(lambda x: makeReverseTuple(x))
	reverse_edges_df = reverse_edges.toDF(["src", "dst"])

	all_edges_combined = edges.union(reverse_edges)
	#all_edges.sortByKey() #sort probably will not help
	all_edges_df_combined = edges_df.union(reverse_edges_df) 

        # convert edges to dataframe
	all_edges_df_table = all_edges_df_combined.createOrReplaceTempView("all_edges_df_table")
	all_edges_df_table_data = spark.sql("select * from all_edges_df_table ")

	edges_df.registerTempTable('edges_df')	
	edge_count_src = spark.sql("select max(src) as s_node, count(*) as src_outgoing_edge_count from  edges_df  group by src") # order by int(s_node)")

	# as this is reverse edges hence src column is the destination node in the input file
	reverse_edges_df.registerTempTable('reverse_edges_df')
	edge_count_dst = spark.sql("select max(src) as d_node, count(*) as dst_outgoing_edge_count from  reverse_edges_df  group by src") # order by int(d_node)")


	combined_outgoing_edge_count_src = edges_df.join(edge_count_src, edges_df.src==edge_count_src.s_node)
	combined_outgoing_edge_count_dst = reverse_edges_df.join(edge_count_dst, reverse_edges_df.src==edge_count_dst.d_node)

	# works though need cleaning
	#df_data_for_modularity_src =combined_outgoing_edge_count_src.join(combined_outgoing_edge_count_dst,  (   (combined_outgoing_edge_count_src.src==combined_outgoing_edge_count_dst.dst)   &     (combined_outgoing_edge_count_src.dst==combined_outgoing_edge_count_dst.src) ) )


	df_data_for_modularity_src =combined_outgoing_edge_count_src.join(combined_outgoing_edge_count_dst,  (   (combined_outgoing_edge_count_src.src==combined_outgoing_edge_count_dst.dst)   &     (combined_outgoing_edge_count_src.dst==combined_outgoing_edge_count_dst.src) ) ).select(combined_outgoing_edge_count_src.src, combined_outgoing_edge_count_src.dst,  combined_outgoing_edge_count_src.src_outgoing_edge_count,  combined_outgoing_edge_count_dst.dst_outgoing_edge_count )

	df_data_for_modularity_src.registerTempTable("df_data_for_modularity_src_table")
	modularity_table_reverse_edges=spark.sql("select dst as src, src as dst, dst_outgoing_edge_count as src_outgoing_edge_count, src_outgoing_edge_count as dst_outgoing_edge_count from df_data_for_modularity_src_table  ")

	combined_modularity_table = df_data_for_modularity_src.union(modularity_table_reverse_edges)


	#combined_outgoing_edge_count = all_edges_df_table_data.join(edge_count_src, all_edges_df_table_data.src==edge_count_src.s_node).join(edge_count_dst, all_edges_df_table_data.dst == edge_count_dst.d_node)
	 #combined_outgoing_edge_count = all_edges_df_table_data.join(edge_count_src, all_edges_df_table_data.src==edge_count_src.s_node).join(edge_count_dst, all_edges_df_table_data.dst == edge_count_dst.d_node)



	node_edge_list_source = spark.sql("select src as n_src , concat_ws(',', collect_list(dst)) as edges_from_source from  all_edges_df_table group by src")

	#old approach - needs to be removed
	#all_edges_df_table_with_edges = combined_outgoing_edge_count.join(node_edge_list_source, combined_outgoing_edge_count.src==node_edge_list_source.n_src)
	#new approach
	all_edges_df_table_with_edges = combined_modularity_table.join(node_edge_list_source, combined_modularity_table.src==node_edge_list_source.n_src)



	#node_edge_list_1 = spark.sql("select src, concat_ws(',', collect_list(dst)) as edges from  ll_edges_df_table group by src")
	#node_edge_list_2 = spark.sql("select dst, concat_ws(',', collect_list(src)) as edges from  all_edges_df_table   group by dst")
        
	#node_edge_list = node_edge_list_1.union(node_edge_list_2)
	#node_edge_list.show()

	
	communities = all_edges_df_table_with_edges
	communities.show()


	# count total number of edges
	communities.createOrReplaceTempView("communities_table")
	#use of variables
	total_edge_count = spark.sql('select sum(src_outgoing_edge_count) total_edge_count from communities_table')
	total_edge_count = total_edge_count.take(1)
	two_m = total_edge_count[0].__getitem__("total_edge_count")

	# calculate initial Q values for all nodes
	initial_and_merged_q_values =  spark.sql("SELECT src, dst, src_outgoing_edge_count, dst_outgoing_edge_count, edges_from_source, src_outgoing_edge_count * src_outgoing_edge_count/{} as initial_q_val,   src_outgoing_edge_count * dst_outgoing_edge_count/{} as q_value_if_merged,        communities_table.*  from communities_table".format(two_m, two_m))
	initial_and_merged_q_values.show()


	# I could create a table from previous data frame that could make the sql look pretty
        # also the diff could be calculated in the prev sql as well
	q_value_gain_if_merged = spark.sql("SELECT src as q_diff_src, src_outgoing_edge_count * src_outgoing_edge_count/{} - src_outgoing_edge_count * dst_outgoing_edge_count/{} as q_val_diff_if_merged  from communities_table".format(two_m, two_m))
	q_value_gain_if_merged.show()	

	combine_diff_q_values = initial_and_merged_q_values.join(q_value_gain_if_merged, q_value_gain_if_merged.q_diff_src==initial_and_merged_q_values.src)
	combine_diff_q_values.show()


	# just doing in one step than multiple steps
	initial_and_merged_q_values =  spark.sql("SELECT src, dst, src_outgoing_edge_count, dst_outgoing_edge_count, edges_from_source, src_outgoing_edge_count * src_outgoing_edge_count/{} as initial_q_val,   src_outgoing_edge_count * dst_outgoing_edge_count/{} as q_value_if_merged,  (src_outgoing_edge_count * dst_outgoing_edge_count/{}) - (src_outgoing_edge_count * src_outgoing_edge_count/{}) as q_val_diff_if_merged from communities_table".format(two_m, two_m, two_m, two_m))
	
	combine_diff_q_values = initial_and_merged_q_values


	#get q values and differences at the same time
	#merge_q_values =  spark.sql("SELECT ee.src, ee.dst,ee.src_outgoing_count * ee.src_outgoing_count/{} as previous_q, ee.src_outgoing_count*ee.dst_outgoing_count/{} as merge_q_val,  ee.src_outgoing_count * ee.src_outgoing_count/{}  -  ee.src_outgoing_count*ee.dst_outgoing_count/{} from edges_table ee ".format(two_m, two_m, two_m, two_m))


	# now we are at a stage to combine nodes for communities
	# at each stage/iteration, check the q_val increase by source, and take the maximum merged among +ves and combine


	# count total number of edges
	combine_diff_q_values.createOrReplaceTempView("table_for_community_detection")

	grouped_for_max_change = spark.sql("select max(src) as src, max(q_val_diff_if_merged) as q_val_diff_if_merged  from table_for_community_detection group by src")


	merge_destination = grouped_for_max_change.join(combine_diff_q_values, (  (grouped_for_max_change.src==combine_diff_q_values.src) & (grouped_for_max_change.q_val_diff_if_merged==combine_diff_q_values.q_val_diff_if_merged))   ).select(grouped_for_max_change.src, grouped_for_max_change.q_val_diff_if_merged, combine_diff_q_values.dst)
	merge_destination.show()


	#merge_destination_d = grouped_for_max_change.join(combine_diff_q_values, (  (grouped_for_max_change.src==combine_diff_q_values.src) & (grouped_for_max_change.q_val_diff_if_merged==combine_diff_q_values.q_val_diff_if_merged))   ).select(combine_diff_q_values.dst, grouped_for_max_change.q_val_diff_if_merged, combine_diff_q_values.src)
	#merge_destination=merge_destination.union(merge_destination_d)


	#all data for selected rows might help
	t1_matched_rows=combine_diff_q_values.join(merge_destination, (combine_diff_q_values.src == merge_destination.src) & (combine_diff_q_values.dst == merge_destination.dst) ).select(combine_diff_q_values.src,   combine_diff_q_values.dst, combine_diff_q_values.src_outgoing_edge_count, combine_diff_q_values.dst_outgoing_edge_count, combine_diff_q_values.edges_from_source,      combine_diff_q_values.initial_q_val, combine_diff_q_values.q_value_if_merged, combine_diff_q_values.q_val_diff_if_merged)



#better to move up then matched rows will show both straight and reverse data
merge_destination_d = grouped_for_max_change.join(combine_diff_q_values, (  (grouped_for_max_change.src==combine_diff_q_values.src) & (grouped_for_max_change.q_val_diff_if_merged==combine_diff_q_values.q_val_diff_if_merged))   ).select(combine_diff_q_values.dst, grouped_for_max_change.q_val_diff_if_merged, combine_diff_q_values.src)


        merge_destination=merge_destination.union(merge_destination_d)








	#worked  with considering reverse rows
	t1_not_matched_rows=combine_diff_q_values.join(merge_destination, (combine_diff_q_values.src == merge_destination.src) & (combine_diff_q_values.dst == merge_destination.dst), "leftanti" ).select(combine_diff_q_values.src,   combine_diff_q_values.dst, combine_diff_q_values.src_outgoing_edge_count, combine_diff_q_values.dst_outgoing_edge_count, combine_diff_q_values.edges_from_source,      combine_diff_q_values.initial_q_val, combine_diff_q_values.q_value_if_merged, combine_diff_q_values.q_val_diff_if_merged)



	# rows/edges that do not need a merge --- did not work actually
	#no need as the previous step took care of that
	# t2=combine_diff_q_values.join(merge_destination, (combine_diff_q_values.src != merge_destination.src) & (combine_diff_q_values.dst != merge_destination.dst) ).select(combine_diff_q_values.src,   combine_diff_q_values.dst, combine_diff_q_values.src_outgoing_edge_count, combine_diff_q_values.dst_outgoing_edge_count, combine_diff_q_values.edges_from_source,      combine_diff_q_values.initial_q_val, combine_diff_q_values.q_value_if_merged, combine_diff_q_values.q_val_diff_if_merged)


"""
		huge_df = huge_df.join(filter_df, huge_df.id == filter_df.id, "left_outer")
                 .where(filter_df.id.isNull())
                 .select([col(c) for c in huge_df.columns]

"""

	t1_matched_rows.registerTempTable("nodes_to_be_merged_data")
	global_node_just_merged = []
	global_node_just_merged_s = t1.rdd.map(lambda x: x["src"] )
	global_node_just_merged_d = t1.rdd.map(lambda x: x["dst"])

	#not ideal however have to purge rows as merge_nodes did not work as expected
	global_node_just_merged = []
	must_merge = []
	for x in t1_matched_rows.collect():
		if ( x['src'] not in global_node_just_merged ) and ( x['dst'] not in global_node_just_merged ) :
			must_merge.append(x)
			global_node_just_merged.append(x['src'])
			global_node_just_merged.append(x['dst'])

	must_merge_df = sc.parallelize(must_merge).toDF(["src", "dst", "src_outgoing_edge_count", "dst_outgoing_edge_count", "edges_from_source",      "initial_q_val",  "q_value_if_merged", "q_val_diff_if_merged"])
	transformed_merged_data = must_merge_df.rdd.map(lambda x: merge_nodes(x))

	

	#filtered = pp.filter(lambda x: x[0][1] not in global_node_just_merged )
	#pp = t1.rdd.map(lambda x: merge_nodes(x))
	#edges = pp
	merge_rows = []
	for aRow in transformed_merged_data.collect():
		merge_rows.append(aRow[0])

	merge_rows = sc.parallelize(merge_rows)

	# this block is actually a bad practice. some rows need to be removed as part of transformations
	"""
	will be cleaned
	global_node_just_merged = []
	for aRow in merge_rows:
		if (aRow[1]in global_node_just_merged):
			merge_rows.remove(aRow)
		global_node_just_merged.append(aRow[0].split('~')[0])
		global_node_just_merged.append(aRow[0].split('~')[1])
	"""

	#merge_rows.toDF()
	merge_rows_df = merge_rows.toDF(["src", "dst", "src_outgoing_edge_count", "dst_outgoing_edge_count", "edges_from_source",      "initial_q_val",  "q_value_if_merged", "q_val_diff_if_merged"])

	#not required
	#transformed_merged_data=transformed_merged_data.toDF(["src", "dst", "src_outgoing_edge_count", "dst_outgoing_edge_count", "edges_from_source",      "initial_q_val",  "q_value_if_merged", "q_val_diff_if_merged"])

	next_iteration_data = merge_rows_df.union(t1_not_matched_rows)

	"""

		logic at this point:

		all_data = "table_for_community_detection" or combine_diff_q_values
		nodes_to_be_merged_data = t1
		
		what to do?
		all_data_without_merged_node_data = remove t1 rows from all_data
		generate new node labels :  src ~ dst from t1
		for edges column replace node-id with the merged node id i.e. instead of 2 and 4 replace with 2~4
		create new nodes for t1 in all_data_without_merged_node_data

		
		
	"""

	"""
	for i in range(1):
	...     grouped_for_max_change = spark.sql("select max(src) as src, max(dst) as dst, max(q_val_diff_if_merged) as q_val_diff_if_merged  from " + table + " group by src")
	...     grouped_for_max_change.createOrReplaceTempView(table + "_" + i)                                                                                          ...     table = table + "_" + i
	...     grouped_for_max_change.show()

	"""


	table = "table_for_community_detection"
	for i in range(2):
		grouped_for_max_change = spark.sql(" select max(src) as src, max(q_val_diff_if_merged) as q_val_diff_if_merged  from " +  table + " group by src")
		table = table + "_" + str(i+1)
		grouped_for_max_change.createOrReplaceTempView(table)
		grouped_for_max_change.show()


if __name__  == "__main__":
	conf = SparkConf().setAppName("Spark Louvain Modularity")
	sc = SparkContext(conf = conf)
	main(sc)
	sc.stop()



# References:
# read graph file using spark: https://stackoverflow.com/questions/41144218/pyspark-creating-a-data-frame-from-text-file
# https://networkx.github.io/documentation/stable/reference/readwrite/generated/networkx.readwrite.edgelist.read_edgelist.html
# read_edgelist(path, comments='#', delimiter=None, create_using=None, nodetype=None, data=True, edgetype=None, encoding='utf-8')
