from pyspark import SparkConf, SparkContext
from pyspark.sql import SQLContext
#from graphframes.examples import * 
from graphframes import *

#make tuples from line
def makeTuple(line):
	words = line.split()
	#return (words[0].strip(), words[1].strip())
	return (words[0].strip(), words[1].strip(), "", "", "", "", "", "", "", "")
	
# find all tokens
def makeSeparate(line):
	words = line#.split()
	l = []
	l.append(words[0])
	l.append(words[1])
	return l

def calculate_initial_parameter_values(sc, g, v, e):
	print('hello')

# start of the program
inputFilePath = '/user/root/louvain/dataset/quora.txt'
def main(sc):
	sqlContext = SQLContext(sc)
	#spark reading of graph from file
	input_file = sc.textFile(inputFilePath)

        #EDGES
	edges = input_file.map(lambda x: makeTuple(x))
	e = sqlContext.createDataFrame(edges, ["src", "dst", "src-outgoing-count", "dst-outgoing-count", "total-count-src-dst", "initial Q", "src-dst-q-change", "best-q-change", "best-dst-node", 'edge-destinations' ])
	e.show()

        # VERTICES
	v = edges.map(lambda line: makeSeparate(line))
	vertices = []
	for x in edges.collect():
      	    vertices.append(x[0])
      	    vertices.append(x[1])
	vertice_set = set (vertices)
	vertices = []
	for aNode in vertice_set:
	    vertices.append( (aNode, "" ) )
	# convert graph data to GraphFrame
	# Vertex DataFrame
	v = sqlContext.createDataFrame(vertices, ["id", ''])
	# Edge DataFrame
	e = sqlContext.createDataFrame(edges, ["src", "dst"])
	# Create a GraphFrame
	g = GraphFrame(v, e)
        g.vertices.show()


 	#from pyspark.sql.types import SparkSession
    	from pyspark.sql.types import StructType, StructField, StructField, StringType
    	from pyspark.sql import SparkSession
    	spark = SparkSession \
        	.builder \
        	.appName("Spark Search Engine") \
        	.getOrCreate()


        # convert edges to dataframe
 	ee = sqlContext.createDataFrame(edges)
        #convert dataframe to tables
        ee.createOrReplaceTempView("edges_table")
        
        all_from_edges = spark.sql("select * from edges_table")
        all_from_edges.show()


        # create schema based tables for edges
	from pyspark.sql.types import StructType, StructField, StructField, StringType
	#edgesSchema = StructType([StructField("src", StringType(), True), StructField("dst", StringType(), True)])
	edgesSchema = StructType([StructField("src", StringType(), True)
		, StructField("dst", StringType(), True)
		, StructField("src-outgoing-count", StringType(), True)
		, StructField("dst-outgoing-count", StringType(), True)
		, StructField("total-outgoing", StringType(), True)
		, StructField("initial-q", StringType(), True)
		, StructField("src-dst-q-change", StringType(), True)
		, StructField("best-q-val", StringType(), True)
		, StructField("best-dst-node", StringType(), True)
		, StructField("edge-destinations", StringType(), True)
		])
	ee = sqlContext.createDataFrame(edges, edgesSchema)


	#convert dataframe to tables
        ee.createOrReplaceTempView("edges_table")

        all_from_edges = spark.sql("select * from edges_table order by src, dst")
        all_from_edges.show()


if __name__  == "__main__":
	conf = SparkConf().setAppName("Spark Louvain Modularity")
	sc = SparkContext(conf = conf)
	main(sc)
	sc.stop()



# References:
# read graph file using spark: https://stackoverflow.com/questions/41144218/pyspark-creating-a-data-frame-from-text-file
# https://networkx.github.io/documentation/stable/reference/readwrite/generated/networkx.readwrite.edgelist.read_edgelist.html
# read_edgelist(path, comments='#', delimiter=None, create_using=None, nodetype=None, data=True, edgetype=None, encoding='utf-8')
