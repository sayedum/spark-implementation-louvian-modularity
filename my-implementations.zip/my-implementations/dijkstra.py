import networkx as nx
import sys
# list of nodes, edges
node_list = list()
node_list_for_path = list()
edge_list = list()

# read graph structure from a file. The graph is kept in a python Dictionary data structure
# graph is a dictionary where key is a tuple with edges (from -> to ) and value is the distance between them
# graph [('5', '6')] = 10 : distance between 5 and 6 is 10

#just for testing with networkx
G = nx.Graph()

# actual graph to work on
graph = {}
def read_graph_from_file():

    # edgelist.classnote has the example graph from class note - with weight 1 for all
    # edgelist.classnote.weight has the example graph from class note - with weights as are on the class note

    # read graph file
    #graph_file = open('edgelist.classnote.weight')
    graph_file = open('karate.edgelist')


    for line in graph_file:
        try:
            # remove whitespaces - trailing and before
            line = line.strip()
            edges = line.split()
        except:
            continue

        # to be an edge two nodes should be on the line
        if len(edges) >= 2:
            current_tuple = tuple(edges)
            reverse_tuple = (edges[1], edges[0])
            if (current_tuple not in edge_list) and (reverse_tuple not in edge_list):

                #add to edge list
                edge_list.append(current_tuple)

                # assign weight if provided else assign 1 as weight 1 => for traversal edge count
                graph[(edges[0], edges[1])] = int(edges[2]) if len(edges) > 2 else 1 #int(edges[2]) #1
                nx.add_path(G, [edges[0], edges[1], 1])

                #create a list of the unique nodes
                for item in edges[0:2]:
                    try:
                        if item not in node_list:
                            node_list.append(item)
                            node_list_for_path.append(item)
                    except:
                        continue


# format of result_matrix_dict dictionary: where key is a tuple with a vertex and distance from source (s)
# value - previous vertex visited
# result_matrix_dict[vertex_to_from_source, distance_calculated_so_far] = previous vertex visited
# example ('5', 9): '4'}  : to reach to node '5', the cost is 9. previous vertex is 4

result_matrix_dict = {}
maxDistance = sys.maxsize
def initialize_result_matrix_dict(graph, s):

    # for source assign visit distance =0 and prev vertex ''
    result_matrix_dict[(s, 0)] = ''

    #removing temporarily as we want to avoid comparison in the lopp below
    node_list.remove(s)

    # initial distance is infinity for all nodes except source (source to source = 0). Also prev vertex is '' for all nodes
    for aNode in node_list:
        result_matrix_dict[(aNode, maxDistance)] = ''

    # adding the source node again to the output result matrix/dictionary - just skipped comparison
    node_list.append(s)

    print('\nOutput dictionary just after initialization')
    print(result_matrix_dict)


# pick the node to visit next. Select the node that has the minimum distance from the source so far
def pick_min_dist_node_from_unvisited_queue(picked_list):
    min_dist_local = maxDistance
    tuple_with_min_dist = ''
    for aDictItem in result_matrix_dict:
        if aDictItem[0] in picked_list:
            continue

        if ( int(aDictItem[1]) ) < min_dist_local:
            min_dist_local = int(aDictItem[1])
            tuple_with_min_dist = aDictItem

    return(tuple_with_min_dist)

# find all unvisited neighbours for a node that we are visiting right now
def find_all_neighbours(g, v, queue_unvisited, picked_list):
    neigh = []
    for x in g.keys():
        if v == x[0]:
            if (x[0] not in neigh) and (x[0] in queue_unvisited):
                neigh.append(x[1])
        if v == x[1]:
            if (x[1] not in neigh) and (x[1]  in queue_unvisited):
                neigh.append(x[0])

    return(neigh)

# find the distance from a source node (the one picked to be visited from the result dictionary with minimum distance)
# to a neighbour node
def distance_from_source_to_aNeighbour_fn(pick_node, aNeighbour, cDistance = 0):

    #include the distance to the picked node i.e. this is the minimum from source - so far
    cDistance = int(pick_node[1])

    # add the distance from the graph picked node to neighbour node
    # consider reverse edge possibility as well [we actually did not add reverse edge]
    try:
        if (graph[(pick_node[0], aNeighbour)]):
            cDistance += graph[(pick_node[0], aNeighbour)]
    except:
        try:
            # reverse edge
            if (graph[(aNeighbour, pick_node[0])]):
                cDistance += graph[(aNeighbour, pick_node[0])]
        except:
            # print('exception happened for %d %d', pick_node[0], aNeighbour)
            return cDistance

    return cDistance


# dijkstra algorithm for single source shortest path
#s is the source
def dijkstra(graph, s='1'):
    # result_matrix_dict will be used for Shortest-path matrix/dictionary/output
    initialize_result_matrix_dict(graph, s)

    # queue_unvisited will be used as Queue of nodes to visit i.e. unvisited so far
    queue_unvisited = node_list
    
    
    #already visited nodes list
    picked_list = []

    # pick_min_dist_node_x_u: pick a node from the result dictionary with the minimum distance from source: to be visited next
    # pick the winner
    pick_min_dist_node_x_u = {}

    while ( len(queue_unvisited) > 0 ):
        pick_min_dist_node_x_u = pick_min_dist_node_from_unvisited_queue(picked_list)
        neighbour_remaining = find_all_neighbours(graph, pick_min_dist_node_x_u[0], queue_unvisited, picked_list)
        distance_from_source_to_aNeighbour = 0
        for aNeighbour in neighbour_remaining:
            distance_from_source_to_aNeighbour = distance_from_source_to_aNeighbour_fn(pick_min_dist_node_x_u, aNeighbour)
            prev_distance = 0

            # distance already are there in the output matrix/dictionary
            for node, dist in list(result_matrix_dict.keys()):
                if node == aNeighbour:
                    prev_distance = dist
                    break
            # replace with lower distance if any (distance considering picked node)
            if ( distance_from_source_to_aNeighbour < prev_distance ):
                # replace distance. remove dictionary item and then add
                # python must have easier/one-line ways to replace. for now, removing and adding
                del result_matrix_dict[(aNeighbour, prev_distance)]
                result_matrix_dict[(aNeighbour, distance_from_source_to_aNeighbour)] = pick_min_dist_node_x_u[0]

        #picked node is visited at this point. Add to the picked list
        picked_list.append(pick_min_dist_node_x_u[0])

        # remove the picked node from the unvisited queue as we just visited the picked node (it's neighbours)
        if pick_min_dist_node_x_u[0] in queue_unvisited:
            queue_unvisited.remove(pick_min_dist_node_x_u[0])

##------------------main----Code------start
# create the graph
read_graph_from_file()
print('\nThe GRAPH')
print('No of nodes %s' %len(node_list))
print('No of Edges %s' %len(edge_list))
print(graph)


print('\nPlease give a source vertex')
s = input()
print(s)
#s = '1'

# execute/call the algorithm
dijkstra(graph, s)

print('\nFinal Result Matrix with Single Source all Shortest Path')
print("#format: example ('5', 9): '4'}  : to reach to node '5', the cost is 9. previous vertex is 4")
print(result_matrix_dict)

def find_the_path_to_a_node(to, prev_vertex):
    path = ''
    for key, val in result_matrix_dict.keys():
        if (key==prev_vertex):
            path += '<-' + key
            if key == s:
                break;
                return(path)

            #if ( prev_vertex == s ):
            if ( result_matrix_dict[(key, val)] == s):
                path += '<-'
                path += s
                break
                return(path) # + '->' + s)
            else:
                path += find_the_path_to_a_node(prev_vertex, result_matrix_dict[(key,val)])
                
    return(path)

def print_all_shortest_paths():
    for aKey, value in result_matrix_dict.keys():
        if aKey == s:
            continue
        else:
            aNode = aKey
            found_path = find_the_path_to_a_node(aNode, result_matrix_dict[(aKey, value)])
            print('path to %s' %aNode)
            if (found_path):
                print(aKey + found_path)

print('\nThe shortest paths from the source to all nodes')
print_all_shortest_paths()

#nx.dijkstra_path(graph, '1', 30)
#print(list(nx.all_shortest_paths(graph, source=found_path1, target=30, method='dijkstra')))

try:
    print('\n\nResult with networkx library (Networkx)')
    print('\n1. all shortest paths to node 27 (used networkx.all_shortest_paths() )')
    print([p for p in nx.all_shortest_paths(G, source=s,  target='27', method='dijkstra')])


    print('\n2. Shortest paths to different nodes (Networkx)')
    length = nx.single_source_shortest_path(G, source=s)
    print(length)
except:
    print('Exception: networkx based statements did not produce any output. the input graph might not be appropriate')


#print([p for p in nx.single_source_shortest_path(G, source='1',   method='dijkstra')])
#nx.all_shortest_paths(G, source='1',  target='27', method='dijkstra')

