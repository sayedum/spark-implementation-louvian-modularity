#to keep global variables
import global_config as glbl
import input_graph_creation as input
import mst as mst

# generate k spanning tree using similarity
# similarity: remove edges with the lowest weight
def kspanning_tree(mst_output):    
    i = 0
    k = int(glbl.k)

    # actually all the nodes in the removed edges    
    separated_nodes = set()
    
    # edges to remove with minimum weights
    del_edges = []
    
    # find k-1 edges with the minimum weights
    # similarity: remove edges with the lowest weight
    mst_output_copy = mst_output.copy()
    while ( i < k - 1 ):
        del_edge = min(mst_output, key=mst_output.get) # ref: stackoverflow
        
        # nodes in the edges to delete 
        separated_nodes.add(del_edge[0])
        separated_nodes.add(del_edge[1])
        
        # edges to delete
        del_edges.append(del_edge)
        del mst_output[del_edge]
        i += 1
    
    # traverse the tree and keep printing until  to delete edges met and continue
    print('\nK spanning tree')
    aTree = {}
    tree_nodes = set()
    for anItem in mst_output_copy:
        if (anItem in del_edges):
            # to delete edge met; so print the cluster
            if (aTree):
                print(aTree)
            aTree = {}
        else:
            # traverse tree
            aTree[anItem] = mst_output_copy[anItem]
            tree_nodes.add(anItem[0])
            tree_nodes.add(anItem[1])
    
    if (aTree):
        print(aTree)
        
    # print the nodes that were separated from the tree as part of edge removal    
    for aNode in separated_nodes.difference(tree_nodes):
        print(aNode)     
            
    #print('\nK spanning tree')
    #return(mst_output, separated_nodes)
              
#input.create_graph_from_gml_file('hep-th.gml')
input.create_graph_from_gml_file('mst-input.txt')
mst_output = {}
mst_output = mst.mst_prim(glbl.graph)
kspanning_tree(mst_output)



#reference
#https://docs.python.org/2/faq/programming.html#how-do-i-share-global-variables-across-modules