import numpy as np
import sys

# a list of edges
edge_list = list()

#the overall graph in dictionary format
graph = {}

#list of nodes along with some attributes such as outgoing edge count, Q value, Q/Modularity value change
# communities will be kept here as well or community data structure will be based on this
node_list = {}

# store destination nodes for each source node
node_edge_list = {}

# read graph structure from a file. The graph is kept in a Python Dictionary data structure
# graph is a dictionary where key is a tuple with edges (from -> to ) and value is the distance/weight between them.
# graph [('5', '6')] = 1 : distance between 5 and 6 is 1
def read_graph_from_file(input_file):
    # read graph file
    graph_file = open(input_file)

    for line in graph_file:
        try:
            # remove white spaces - trailing and before
            line = line.strip()
            if (line == ""):
                continue
            edges = line.split()

        except:
            continue

        # to be an edge two nodes should be on the line
        if len(edges) >= 2:
            current_tuple = list()
            current_tuple.clear()
            # create a list of the unique nodes
            for item in edges:
                item = item.strip()

                try:
                    if item not in node_list:
                        #node_list.append(item)
                        node_list[item] = 1
                        node_edge_list[item] = []

                    else:
                        node_list[item] = node_list[item] + 1
                        #node_edge_list[item] = node_edge_list[item].append(item)
                except:
                    print('exception')
                    continue
                    # exit(1)

            current_tuple = (edges[0].strip(), edges[1].strip())
            current_tuple = tuple(current_tuple)
            reverse_tuple = (current_tuple[1], current_tuple[0])

            #keep track of destination nodes by each node
            if current_tuple[1] not in node_edge_list[current_tuple[0]]:
                node_edge_list[current_tuple[0]].append(current_tuple[1])

            if current_tuple[0] not in node_edge_list[current_tuple[1]]:
                node_edge_list[current_tuple[1]].append(current_tuple[0])

            if (current_tuple not in edge_list) and (reverse_tuple not in edge_list):
                # add to edge list
                edge_list.append(current_tuple)

                # add to the graph
                graph[(current_tuple[0], current_tuple[1])] = 1 #(current_tuple[0], current_tuple[1])

def calculate_overall_modularity(sorted_graph_keys):
    return

# calculate initial modularity when each node is it's own community
def calculate_initial_modularity(communities):
    #  edge weight between two nodes
    Aij = 0

    #sum of the weights of the edges attached to vertex i
    Ki = 0

    # delta function – 1 if ci = cj; 0 otherwise
    delta = 0

    # sum of all of the edge weights in the graph
    two_m = calculate_m() #len(edge_list)

    # modularity
    Q = 0
    for aNode in communities:
        Q_1 = 1/(two_m)
        Q_2 = (-1) * (communities[aNode] * communities[aNode])/(two_m)
        Q_3 = 1
        Q = Q_1 * Q_2 * Q_3

        #                    (out-going-edge-count, Q value)
        communities[aNode] = (communities[aNode], Q)

    return (communities)

# calculate modularity value between two nodes with an edge
def calculate_modularity_between_edges(nodei, nodej, tempCommunities):
    #  edge weight between two nodes
    Aij = 0

    # sum of the weights of the edges attached to vertex nodei
    Ki = 0

    # sum of the weights of the edges attached to vertex nodej
    Kj = 0

    # 1 when ci = cj else 0
    delta = 0

    # 2 * count of all edges
    two_m = calculate_m() #len(edge_list)

    if node_edge_list[str(nodei)]:
        Aij = 1
    elif node_edge_list[str(nodej)]:
        Aij = 1


    Q = 0
    #for aNode in communities:
    Q_1 = 1/(two_m)
    #Q_2 = Aij - int(node_edge_list[str(nodei)][0]) * int(node_edge_list[str(nodej)][0])
    Q_2 = Aij - int(node_list[str(nodei)]) * int(node_list[str(nodej)])/(two_m)
    Q_3 = 1 # delta is 1, we are calculating only when an edge exist

    #Q = Q_1 * Q_2 * Q_3
    Q = Q_2 * Q_3

    outgoing_count_if_merged = int(node_list[str(nodei)]) + int(node_list[str(nodej)])

    return Q, outgoing_count_if_merged

def calculate_m():
    return sum([val for key, val in node_list.items()])

def change_communities(merge_pairs_copy):
    merge_pairs_copy = sorted(merge_pairs, key=lambda x: x[0], reverse = True)

    # merge or change communities
    for anItem in merge_pairs_copy:
        try:
            if (communities[anItem[0]]) and (communities[anItem[1]]):
                # update communities [from node_list]
                del communities[anItem[0]]
                del communities[anItem[1]]
                new_q_val = merge_pairs[anItem][2]/(2*len(edge_list))
                communities[anItem[0] + '~' + anItem[1]] = (merge_pairs[anItem][1], new_q_val) # (outgoing_count_if_merged, max_q_value)

                #update node_edge_list
                new_edges = list(set(np.append(node_edge_list[anItem[0]], node_edge_list[anItem[1]])))
                new_edges.remove(anItem[0])
                new_edges.remove(anItem[1])


                del node_edge_list[anItem[0]]
                del node_edge_list[anItem[1]]
                #node_edge_list[anItem[0] + '~' + anItem[1]] = []
                node_edge_list[anItem[0] + '~' + anItem[1]] = new_edges

                # update node list
                del node_list[anItem[0]]
                del node_list[anItem[1]]
                node_list[anItem[0] + '~' + anItem[1]] = len(new_edges)

                #update entire node_edge list
                for key, val in node_edge_list.items():
                    new_val = []
                    if (anItem[0] in val):
                        val.remove(anItem[0])
                        val.append(anItem[0] + '~' + anItem[1])
                        if (anItem[1] in val):
                            val.remove(anItem[1])
                        node_edge_list[key] = val
                    elif (anItem[1] in val):
                        val.remove(anItem[1])
                        val.append(anItem[0] + '~' + anItem[1])
                        if (anItem[0] in val):
                            val.remove(anItem[0])
                        node_edge_list[key] = val


        except:
            continue

    return merge_pairs_copy

# read_graph_from_file('datasets\email-Eu-core.txt')
read_graph_from_file('datasets\quora.txt')
#print(graph)

print(node_edge_list)

communities = node_list.copy()
print(communities)
communities = calculate_initial_modularity(communities)
print(communities)

sorted_graph_keys = sorted(graph)
print(sorted_graph_keys)

max_iterations = 10000  * len (node_list)
iter = 0
keep_going = True
while (keep_going)  and (iter <= max_iterations):
    tempCommunities = communities.copy()
    merge_pairs = {}
    for keyi, vali in tempCommunities.items():
        q_data = 0
        initial_q_value = vali[1]
        max_q_value = initial_q_value
        max_mod_increase = 0
        merge_with_j = ''

        #for keyj, valj in tempCommunities.items():
        for aNeighbour in node_edge_list[keyi]:
            merge_with_j = aNeighbour # a random selection if modularity does not increase
            q_val, outgoing_count_if_merged = calculate_modularity_between_edges(keyi, aNeighbour, tempCommunities)

            if ( (q_val - initial_q_value ) > max_mod_increase ):
                max_mod_increase = q_val - initial_q_value
                merge_with_j = aNeighbour
                max_q_value = q_val
                new_q_val = initial_q_value + max_q_value

        if ( merge_with_j != '' ):
            merge_pairs[(keyi, merge_with_j)] = (max_mod_increase, outgoing_count_if_merged, max_q_value, new_q_val)
            break
            # del communities[keyi]
            # communities[ keyi + '~'+keyj ] = (outgoing_count_if_merged, max_q_value)
            # node_edge_list[keyi + '~'+keyj] = outgoing_count_if_merged #node_edge_list[keyi].append(node_edge_list[keyj])

        #calculate_overall_modularity(sorted_graph_keys)

    if ( len(merge_pairs) > 0 ):
        change_communities(merge_pairs)
    if (len(communities) == 0):
        keep_going = False
    iter += 1

print('final communities as below')
print(communities)