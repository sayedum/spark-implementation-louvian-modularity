import global_config as glbl
import numpy as np

# read GML file and create a graph
# graph is kept both in a matrix and dictionary - a place for optimization/reduction 
def create_graph_from_gml_file(input_file):    
    graph_file = open(input_file)
    is_edge_start = 0
    for line in graph_file:
        if line.strip() == 'node':
            graph_file.readline()
            key = (graph_file.readline().strip().replace('id ',''))
            #value = graph_file.readline().strip().replace('"','').replace('label ','')
            #glbl.node_list[key] = value  
            glbl.node_list.append(key)
        
        if line.strip() == 'edge':
            if (is_edge_start == 0):
                is_edge_start = 1
                node_count = len(glbl.node_list)
                glbl.graph_matrix = np.zeros((node_count, node_count))
                
            graph_file.readline()
            source = (graph_file.readline().strip().replace('source ',''))
            target = graph_file.readline().strip().replace('"','').replace('target ','')
            weight = (graph_file.readline().strip().replace('weight ',''))
            weight = float(weight)
            glbl.graph[(source, target)] = weight    
            #glbl.graph_alt[source] = (target,weight)    
            glbl.graph_matrix[int(source)][int(target)] = weight
            
            if (glbl.is_directed == 0):
                glbl.graph_matrix[int(target)][int(source)] = weight
