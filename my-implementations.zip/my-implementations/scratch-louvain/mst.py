import global_config as glbl
import random
import sys
from _overlapped import NULL

# Choose an edge that satisfies the following two criteria
# --Exactly one of its edge points is already in MST
# --The edge has the least weight among those that satisfy (1)
def select_min_weight_edge_to_add(edges_under_consideration, mst_node_list):
    min_weight = sys.maxsize
    selected_edge = ()
    for anItem in edges_under_consideration:
        # (anItem[1] not in mst_node_list): to ensure Exactly one of its edge points is already in MST 
        if (edges_under_consideration[anItem] < min_weight) and (anItem[1] not in mst_node_list):  
            selected_edge = anItem
            #to ensure The edge has the least weight among those that satisfy (1)
            min_weight = edges_under_consideration[anItem]
            
    if (len(selected_edge) > 0 ):
        del  edges_under_consideration[(selected_edge[0], selected_edge[1])]
        return {selected_edge:min_weight}
    else:
        return NULL 
                      
# Minimum Spanning Tree 
# Prims Algorithm   
# Input: Undirected Weighted Graph: graph
# Output: MST of Graph: mst_output
def mst_prim(graph):    
    mst_output = {}
    
    #random.seed(0) 
    
    #Initialize MST with arbitrarily chosen node   
    mst_starting_node = glbl.node_list[ random.randint(0, len(glbl.node_list)-1) ]
    mst_node_list = list()
    mst_node_list.append(int(mst_starting_node))
    print('\nFirst Node %s\n' %(mst_starting_node))
        
    # source represents - most recent selected node    
    source = int(mst_starting_node)
    edges_under_consideration = {}
    
    #Repeat until all nodes are part of MST
    while( len(glbl.node_list) > len(mst_node_list) ):
        
        #edges from the most recently selected nodes        
        current_edges = glbl.graph_matrix[source]
        
        min_w = sys.maxsize
        target = 0
        for anEdge in current_edges:            
            if (  anEdge > 0 ): 
                # keep adding new edges to the list to consider in next selection                
                edges_under_consideration[(source, target)] = anEdge
                
                """
                if ( anEdge < min_w ): 
                    min_w = anEdge
                    min_target = target
                """
                    
                    
            target += 1
            
        # Choose an edge that satisfies the following two criteria  
        # --Exactly one of its edge points is already in MST
        # --The edge has the least weight among those that satisfy (1)          
        selected_edge = select_min_weight_edge_to_add(edges_under_consideration, mst_node_list)       
        
        # if no edge is eligible to be selected .. 
        # I could break here as well with or without checking(len(glbl.node_list) > len(mst_node_list)).
        if ( selected_edge == NULL):
            continue
        
        
        # Add edge to MS
        for anItem in selected_edge:
            #Add edge to MS
            mst_output[anItem[0], anItem[1]] = selected_edge[anItem]
            source = anItem[1]
            mst_node_list.append(source)
            try:            
                del glbl.graph[(str(anItem[0]), str(anItem[1]))]
            except:
                del glbl.graph[(str(anItem[1]), str(anItem[0]))]                
            finally:
                glbl.graph_matrix[anItem[0], anItem[1]] = 0
                glbl.graph_matrix[anItem[1], anItem[0]] = 0
                #print('exception')
                                
        
    print('The MST after Prims\' Algorithm')    
    print(mst_output)
    return(mst_output)    

#references:
#https://stackoverflow.com/questions/9415785/merging-several-python-dictionaries