import numpy as np
import random
import sys

#random.seed(random.randint(0,1000))

edge_list =  list()
graph = {}
node_list = list()

# read graph structure from a file. The graph is kept in a Python Dictionary data structure
# graph is a dictionary where key is a tuple with edges (from -> to ) and value is the distance/weight between them.
# graph [('5', '6')] = 1 : distance between 5 and 6 is 1
def read_graph_from_file(input_file):
    # read graph file    
    graph_file = open(input_file)

    for line in graph_file:
        try:
            # remove white spaces - trailing and before
            line = line.strip()
            if (line == ""):
                continue;            
            edges = line.split()
            
        except:
            continue

        # to be an edge two nodes should be on the line
        if len(edges) >= 2:  
            current_tuple = list()   
            current_tuple.clear()      
            # create a list of the unique nodes
            for item in edges:
                item = item.strip()
                try:                    
                    if item not in node_list:                                                
                        node_list.append(item)                                                
                        
                except:
                    print('exception')
                    continue
                    #exit(1)
            
            current_tuple = (edges[0].strip(), edges[1].strip())
            current_tuple = tuple(current_tuple)
            reverse_tuple = (current_tuple[1], current_tuple[0])
            if (current_tuple not in edge_list) and (reverse_tuple not in edge_list):
                # add to edge list
                edge_list.append(current_tuple)
                
                # add to the graph
                graph[(current_tuple[0], current_tuple[1])] = 1
                                
#find number of vertices in a graph
def length_of_graph(CG):
    nodes = set()
    graph_as_set = CG.keys()
    for anItem in graph_as_set:
        nodes.add(anItem[0])
        nodes.add(anItem[1])
    return( len(nodes))    
         
# implement krager algorithm for minimum cut
def karger_min_cut_algorithm(graph):
            
    iteration = 0
    max_iterations = min(1000, 10 * (len(node_list) + len(edge_list)))     
    
    edgecut_count = 0
    min_edgecut_count = sys.maxsize   
    
    H1 = {}
    H2 = {}   
    
    for i in range(max_iterations):                        
        #Initialize contracted graph CG as copy of original graph
        CG = graph.copy()       
        number_of_vertices = length_of_graph(CG)
                       
        while ( number_of_vertices > 2 ):
            
            # Pick a random edge (u, v) in the contracted graph.
            random_edge_nodes = list()
            position_of_edge_to_pick = random.randint( 0, len( CG.keys() ) - 1 )
            graph_in_list = list(CG)
            selected_edge = graph_in_list[position_of_edge_to_pick]
                
            # nodes in the randomly selected edge    
            random_edge_nodes.append( selected_edge[0] )
            random_edge_nodes.append( selected_edge[1] )                        
            
            # delete selected edge. Then these nodes will be treated as one node together                 
            del CG[(selected_edge)]
            CG_copy = CG.copy()
            
            #loop through the graph and replace edges with the combined node edge as applicable    
            for anEdge in CG_copy:
                if (anEdge[0] in random_edge_nodes):
                    CG[(selected_edge[0] + '~' + selected_edge[1], anEdge[1])] = 1
                    del CG[(anEdge)]
                elif (anEdge[1] in random_edge_nodes):
                    CG[(anEdge[0], selected_edge[0] + '~' + selected_edge[1])] = 1
                    del CG[(anEdge)]
            
            
            # remove self loops:             
            CG_copy = CG.copy()
            for anEdge in CG_copy:
                e0 = anEdge[0]
                e1 = anEdge[1]
                
                if ( e0 == e1 ):
                     del CG[(anEdge)]
                     
                #if ( anEdge[0].find(e1) >=0 )  or ( anEdge[1].find(e0) >=0 ):
                    #del CG[(anEdge)]
            
            
            number_of_vertices = length_of_graph(CG)
        
        
        
        #calculate minimum cuts                              
        first_subgraph_nodes = list()
        second_subgraph_nodes = list()
        
        nodes = []
        edgecut_count = 0
        for anEdge in CG:
            first_subgraph_nodes = anEdge[0].split('~')
            second_subgraph_nodes = anEdge[1].split('~')
            
            # find subgraphs in the graph = parameter to this function
            for anItem in graph.copy():
                if (anItem[0] in first_subgraph_nodes) and (anItem[1] in second_subgraph_nodes):
                    edgecut_count += 1                    
                elif (anItem[1] in first_subgraph_nodes) and (anItem[0] in second_subgraph_nodes):    
                    edgecut_count += 1                    
                             
        if (edgecut_count < min_edgecut_count):
            min_edgecut_count = edgecut_count  
            H1 = {}
            H2 = {}                                  
            for anEdge in graph:
                if ( anEdge[0] in first_subgraph_nodes ) and ( anEdge[1] in first_subgraph_nodes ):
                    H1[anEdge] = 1        
                elif ( anEdge[0] in second_subgraph_nodes ) and ( anEdge[1] in second_subgraph_nodes ): 
                     H2[anEdge] = 1
                                           
    return H1, H2, min_edgecut_count

# findout highly connected subgraphs using HCS and krager's minimum cut algorithms
def highly_connected_subgraph():
    subbgraphs_to_process = []
    
    #subbgraphs_to_process = [G]
    subbgraphs_to_process.append(graph)
    
    #highly_connected_subgraphs = []
    highly_connected_subgraphs = []
    
    track_min_cuts = []
    #while subgraphs_to_process is not empty    
    while ( len(subbgraphs_to_process) > 0 ):
        #S = subgraphs_to_process.pop()
        S = subbgraphs_to_process.pop()        
                
        #H1, H2, EC(S)  ← MINIMUMCUT(S)
        H1, H2, EC_S = karger_min_cut_algorithm(S)
        
        #If EC(S) > V(S)/2
        if ( EC_S > length_of_graph(S)/2 ):
            highly_connected_subgraphs.append(S)
            track_min_cuts.append(EC_S)
        #else:
        else:
            #subgraphs_to_process.append(H1)
            # if more than one node in the graph
            if ( length_of_graph(H1) >= 2 ):
                subbgraphs_to_process.append(H1)
            
            if ( length_of_graph(H2) >= 2 ):
                subbgraphs_to_process.append(H2)
                                                 
        
    return highly_connected_subgraphs, track_min_cuts


#read_graph_from_file('D:\MSc Data Science and Analytics\des algorithms\project\my-implementations\scratch-louvain\highly.txt')
read_graph_from_file('D:\MSc Data Science and Analytics\des algorithms\project\my-implementations\scratch-louvain\wiki-input.txt')
#read_graph_from_file('D:\MSc Data Science and Analytics\des algorithms\project\my-implementations\scratch-louvain\cycle1.txt')
highly_connected_subgraphs,  track_min_cuts = highly_connected_subgraph() #H1, H2, EC_S
print('final output')
for aSubGraph in highly_connected_subgraphs:
    print(aSubGraph)
    #print(track_min_cuts.pop())
    
# Reference
# wanted to verify output with this example : https://en.wikipedia.org/wiki/HCS_clustering_algorithm    