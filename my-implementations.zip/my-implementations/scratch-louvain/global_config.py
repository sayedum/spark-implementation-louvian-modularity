import numpy as np

# directed or undirected graph
is_directed = 0

# lists to store nodes and edges
node_list = list()
edge_list = list()

# a dictionary to store the graph
# keys are edges tuples i.e. [(source, target)]
# values are weights of the edges
graph = {}
#graph_alt = {}
graph_matrix = np.zeros((0,0))

k = input('Please enter a value for K\n')
print(k)